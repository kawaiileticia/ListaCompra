package com.asasfracas.ListaCompras;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
     public TextView etlvlista;

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup itemview, int i) {
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder listaViewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static class ListaViewHolder extends RecyclerView.ViewHolder {
        public ListaViewHolder( View itemView) {
            super(itemView);

        }
    }
}
